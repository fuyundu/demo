# SpringBoot2_Activiti7
SpringBoot2集成Activiti7、Swagger、Druid

## 一、环境 ##
- IDEA
- spring2.1.5
- Activiti7
- Swagger 2.9.2
- Druid 1.1.16
- mysql 5.7
- JAVA 8

[![LICENSE](https://img.shields.io/badge/license-Anti%20996-blue.svg)](https://github.com/996icu/996.ICU/blob/master/LICENSE)

