package com.reanod.workflow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Administrator
 */
@SpringBootApplication
public class ReanodWorkflowApplication {

    public static void main(String[] args) {
        SpringApplication.run(ReanodWorkflowApplication.class, args);
    }

}
